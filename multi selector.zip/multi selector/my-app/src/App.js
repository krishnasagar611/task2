import React, { Component } from 'react';
import MultiselectDropdown from './components/MultiSelector';
import './App.css'
class App extends Component {
  render() {
    const options = ['Option 1', 'Option 2', 'Option 3', 'Option 4'];
    return (
      <div className="container">
        <h1>My App</h1>
         <MultiselectDropdown label="select" options={options}/>
      </div>
    );
  }
}

export default App;
